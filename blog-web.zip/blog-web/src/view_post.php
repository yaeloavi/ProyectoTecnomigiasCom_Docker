<?php
session_start();
include("conexion.php");

if (isset($_GET['id'])) {
  $id_post = $_GET['id'];

  // Obtener post
  $sql = "SELECT posts.titulo, posts.contenido, posts.fecha, usuarios.nombre
          FROM posts 
          JOIN usuarios ON posts.id_usuario = usuarios.id
          WHERE posts.id = $id_post";
  $resultado = $conexion->query($sql);
  $post = $resultado->fetch_assoc();

  // Obtener comentarios
  $sqlComentarios = "SELECT comentarios.contenido, comentarios.fecha, usuarios.nombre 
                     FROM comentarios 
                     JOIN usuarios ON comentarios.id_usuario = usuarios.id
                     WHERE comentarios.id_post = $id_post
                     ORDER BY fecha DESC";
  $comentarios = $conexion->query($sqlComentarios);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($post['titulo']); ?> - FIB Blog</title>
  <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
  <header class="main-header">
    <div class="header-content">
      <h1 class="blog-title">FIB Blog - Facultad de Ingeniería UAEMEX</h1>
      <nav class="main-nav">
        <a href="index.php" class="nav-link">Inicio</a>
        <?php if(isset($_SESSION['id_usuario'])): ?>
          <a href="new_post.html" class="nav-link">Nuevo Post</a>
          <a href="logout.php" class="nav-link">Cerrar Sesión</a>
          <span class="user-info">👤 <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
        <?php else: ?>
          <a href="login.html" class="nav-link">Iniciar Sesión</a>
          <a href="register.html" class="nav-link register-btn">Registrarse</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>

  <main class="main-content">
    <div class="container">
      <div class="post-detail">
        <article class="post-full">
          <div class="post-meta">
            <span class="post-author">Por <?php echo htmlspecialchars($post['nombre']); ?></span>
            <span class="post-date">el <?php echo $post['fecha']; ?></span>
          </div>
          <h1 class="post-title"><?php echo htmlspecialchars($post['titulo']); ?></h1>
          <div class="post-content">
            <?php echo nl2br(htmlspecialchars($post['contenido'])); ?>
          </div>
          <div class="post-actions">
            <a href="index.php" class="btn btn-back">← Volver al inicio</a>
          </div>
        </article>

        <section class="comments-section">
          <div class="comments-header">
            <h2 class="comments-title">Comentarios</h2>
            <span class="comments-count">
              (<?php echo $comentarios->num_rows; ?> comentario<?php echo $comentarios->num_rows != 1 ? 's' : ''; ?>)
            </span>
          </div>

          <div class="comments-list">
            <?php if ($comentarios->num_rows > 0): ?>
              <?php while ($c = $comentarios->fetch_assoc()): ?>
                <div class="comment">
                  <div class="comment-header">
                    <span class="comment-author"><?php echo htmlspecialchars($c['nombre']); ?></span>
                    <span class="comment-date"><?php echo $c['fecha']; ?></span>
                  </div>
                  <div class="comment-content">
                    <p><?php echo htmlspecialchars($c['contenido']); ?></p>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php else: ?>
              <div class="no-comments">
                <p>No hay comentarios aún. ¡Sé el primero en comentar!</p>
              </div>
            <?php endif; ?>
          </div>

          <div class="comment-form-container">
            <h3 class="comment-form-title">Deja tu comentario</h3>
            <?php if (isset($_SESSION['id_usuario'])): ?>
              <form action="comentar.php" method="post" class="comment-form">
                <input type="hidden" name="id_post" value="<?php echo $id_post; ?>">
                <div class="form-group">
                  <textarea 
                    name="contenido" 
                    rows="4" 
                    placeholder="Escribe tu comentario aquí..." 
                    class="form-textarea"
                    required
                  ></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Publicar Comentario</button>
              </form>
            <?php else: ?>
              <div class="login-prompt">
                <p><a href="login.html" class="login-link">Inicia sesión</a> para comentar.</p>
              </div>
            <?php endif; ?>
          </div>
        </section>
      </div>
    </div>
  </main>

  <footer class="main-footer">
    <div class="container">
      <p>&copy; 2024 FIB Blog - Facultad de Ingeniería UAEMEX. Todos los derechos reservados.</p>
    </div>
  </footer>
</body>
</html>