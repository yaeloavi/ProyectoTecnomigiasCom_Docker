<?php
$host = 'db';            // nombre del servicio en docker-compose
$user = 'bloguser';
$pass = 'blogpass';
$db   = 'blogdb';

$conexion = new mysqli($host, $user, $pass, $db);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>
