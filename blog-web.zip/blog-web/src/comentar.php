<?php
session_start();
include("conexion.php");

if (isset($_POST['id_post']) && isset($_POST['contenido']) && isset($_SESSION['id_usuario'])) {
    $id_post = $_POST['id_post'];
    $contenido = trim($_POST['contenido']);
    $id_usuario = $_SESSION['id_usuario'];

    if (!empty($contenido)) {
        $sql = "INSERT INTO comentarios (id_post, id_usuario, contenido, fecha) 
                VALUES (?, ?, ?, NOW())";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("iis", $id_post, $id_usuario, $contenido);
        
        if ($stmt->execute()) {
            // Redirigir de nuevo al post
            header("Location: view_post.php?id=" . $id_post);
            exit();
        } else {
            echo "Error al guardar el comentario: " . $conexion->error;
        }
    } else {
        echo "El comentario no puede estar vacío.";
    }
} else {
    echo "Datos inválidos o no has iniciado sesión.";
}
?>
