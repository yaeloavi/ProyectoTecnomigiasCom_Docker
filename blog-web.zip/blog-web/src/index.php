<?php
session_start(); 
include("conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FIB Blog - Facultad de Ingeniería UAEMEX</title>
  <link rel="stylesheet" href="../styles/style.css">
</head>
<body>
  <header class="main-header">
    <div class="header-content">
      <img class="logo" src="../images/logo.png" alt="FIB" width="70px" height="70px">
      <h1 class="blog-title">FIB Blog - Facultad de Ingeniería UAEMEX</h1>
      <nav class="main-nav">
        <a href="index.php" class="nav-link">Inicio</a>
        <?php if(isset($_SESSION['id_usuario'])): ?>
          <a href="new_post.html" class="nav-link">Nuevo Post</a>
          <a href="logout.php" class="nav-link">Cerrar Sesión</a>
          <span class="user-info">👤 <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
        <?php else: ?>
          <a href="login.html" class="nav-link">Iniciar Sesión</a>
          <a href="register.html" class="nav-link register-btn">Registrarse</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>

  <main class="main-content">
    <div class="container">
      <h2 class="section-title">Últimas Publicaciones</h2>

      <div class="posts-container">
        <?php
          $sql = "SELECT posts.id, posts.titulo, posts.contenido, posts.fecha, usuarios.nombre 
                  FROM posts 
                  JOIN usuarios ON posts.id_usuario = usuarios.id
                  ORDER BY fecha DESC";
          $resultado = $conexion->query($sql);

          if ($resultado->num_rows > 0) {
            while($fila = $resultado->fetch_assoc()) {
              echo "<article class='post-card'>";
              echo "<div class='post-header'>";
              echo "<h3 class='post-title'>" . htmlspecialchars($fila['titulo']) . "</h3>";
              echo "</div>";
              echo "<div class='post-content'>";
              echo "<p class='post-excerpt'>" . substr(htmlspecialchars($fila['contenido']), 0, 150) . "...</p>";
              echo "</div>";
              echo "<div class='post-footer'>";
              echo "<small class='post-meta'>Por <span class='author'>" . htmlspecialchars($fila['nombre']) . "</span> el <time>" . $fila['fecha'] . "</time></small>";
              echo "<a href='view_post.php?id=" . $fila['id'] . "' class='read-more'>Leer más</a>";
              echo "</div>";
              echo "</article>";
            }
          } else {
            echo "<div class='no-posts'>";
            echo "<p>No hay publicaciones aún.</p>";
            echo "<a href='login.html' class='cta-button'>¡Sé el primero en publicar!</a>";
            echo "</div>";
          }
        ?>
      </div>
    </div>
  </main>

  <footer class="main-footer">
    <div class="container">
      <p>&copy; 2025 FIB Blog - Facultad de Ingeniería UAEMEX. Todos los derechos reservados.</p>
    </div>
  </footer>
</body>
</html>