<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Verificar que el correo no exista
    $check = $conexion->query("SELECT id FROM usuarios WHERE email = '$email'");
    if ($check->num_rows > 0) {
        echo "⚠️ El correo ya está registrado. <a href='register.html'>Volver</a>";
    } else {
        $sql = "INSERT INTO usuarios (nombre, email, password) VALUES ('$nombre','$email','$password')";
        if ($conexion->query($sql)) {
            echo "✅ Registro exitoso. <a href='login.html'>Iniciar sesión</a>";
        } else {
            echo "❌ Error: " . $conexion->error;
        }
    }
}
?>
