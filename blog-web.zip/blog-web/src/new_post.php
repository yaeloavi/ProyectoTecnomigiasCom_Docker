<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['id_usuario'])) {
    die("⚠️ Debes iniciar sesión para crear un post. <a href='login.html'>Iniciar sesión</a>");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $id_usuario = $_SESSION['id_usuario'];

    $sql = "INSERT INTO posts (titulo, contenido, id_usuario) 
            VALUES ('$titulo', '$contenido', '$id_usuario')";

    if ($conexion->query($sql)) {
        header("Location: index.php"); // Redirige al inicio
        exit();
    } else {
        echo "❌ Error al guardar: " . $conexion->error;
    }
}
?>
