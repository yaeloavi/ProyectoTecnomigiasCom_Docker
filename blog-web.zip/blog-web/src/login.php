<?php
session_start();
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();

        if (password_verify($password, $usuario['password'])) {
            $_SESSION['id_usuario'] = $usuario['id'];
            $_SESSION['nombre'] = $usuario['nombre'];
            echo "✅ Bienvenido " . $usuario['nombre'] . ". <a href='index.php'>Ir al inicio</a>";
        } else {
            echo "❌ Contraseña incorrecta. <a href='login.html'>Intentar de nuevo</a>";
        }
    } else {
        echo "❌ Usuario no encontrado. <a href='login.html'>Intentar de nuevo</a>";
    }
}
?>
